define("monitoring/config/environment",function(){return{default:{modulePrefix:"monitoring"}}})

//# sourceMappingURL=environment-ae56283cbdebf615dfc0e50f9387a420.map