define("login/config/environment",function(){return{default:{modulePrefix:"login"}}})

//# sourceMappingURL=environment-33f85ab8c8131d653434b88697c185a1.map