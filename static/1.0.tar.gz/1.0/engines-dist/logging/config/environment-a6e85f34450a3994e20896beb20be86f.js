define("logging/config/environment",function(){return{default:{modulePrefix:"logging"}}})

//# sourceMappingURL=environment-5af63c459649c97fed31ef3beff2aa09.map