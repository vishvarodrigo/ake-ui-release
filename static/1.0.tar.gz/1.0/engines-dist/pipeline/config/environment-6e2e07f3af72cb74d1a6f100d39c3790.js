define("pipeline/config/environment",function(){return{default:{modulePrefix:"pipeline"}}})

//# sourceMappingURL=environment-67a674ac6795d61b9c37fe09dca6f10f.map