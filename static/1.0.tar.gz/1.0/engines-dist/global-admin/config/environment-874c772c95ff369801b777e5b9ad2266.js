define("global-admin/config/environment",function(){return{default:{modulePrefix:"global-admin",APP:{}}}})

//# sourceMappingURL=environment-6d40c1d476237fc758aaeb9aa04d77b0.map