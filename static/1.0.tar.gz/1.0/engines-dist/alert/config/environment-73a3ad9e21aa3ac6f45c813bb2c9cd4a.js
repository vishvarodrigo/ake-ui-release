define("alert/config/environment",function(){return{default:{modulePrefix:"alert"}}})

//# sourceMappingURL=environment-33f85ab8c8131d653434b88697c185a1.map